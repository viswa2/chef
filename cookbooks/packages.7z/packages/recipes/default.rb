#
# Cookbook:: packages
# Recipe:: default
#
# Copyright:: 2018, The Authors, All Rights Reserved.
#--------------------------------------------
package 'wget' do
	action :install
end
package 'unzip' do
	action :install
end
package 'nano'
package 'tree'

#--------------------------------------------
#APACHE_HTTPD
package 'httpd' do
	action :install
end

service 'httpd' do
 action [:enable, :start]
 end
#--------------------------------------------
directory '/opt/docker' do
 action :create
 end

 file '/opt/docker/docker.sh' do
 action :create
 end
 
 file '/opt/docker/docker.sh' do
 user 'root'
 group 'root'
 mode '0777'
 end
 
 template '/opt/docker/docker.sh' do
	source 'docker.erb'
 end
 
execute '/opt/docker/docker.sh' do
	action :run
end

file '/opt/docker/docker.sh' do
  action :delete
end
execute 'rm -rf /opt/docker'
#--------------------------------------------

execute 'rm -rf /opt/packages'
 
directory '/opt/packages' do
 action :create
 end
 
#---------------------------------------------
# To set Environment variables (write something in bashrc.erb which is located in templates)
 template '/etc/bashrc' do
  source 'bashrc.erb'
end
service 'sshd' do
  action [:restart]
end
#--------------------------------------------
#JAVA_DEVOLOPEMENT_KIT {JDK_1.8}
 
execute 'yum remove -y jdk' do
    command 'yum remove -y jdk'
	cwd '/opt/packages/'
end


file 'opt/packages/jdk.sh' do
  action :create
end

template '/opt/packages/jdk.sh' do
  source 'jdk.erb'
 end
 
execute '/opt/packages/jdk.sh' do
    command 'sh /opt/packages/jdk.sh'
	cwd '/opt/packages/'
end

file '/opt/packages/jdk.sh' do
 action :delete
end
execute '/opt/packages/jdk-8u171-linux-x64.rpm' do
    command 'rpm -ivh /opt/packages/jdk-8u171-linux-x64.rpm'
	cwd '/opt/packages/'
end

file '/opt/packages/jdk-8u171-linux-x64.rpm' do
   action :delete
end

#-------------------------------------------- 

#APACHE_MAVEN

remote_file '/opt/packages/apache-maven-3.5.3-bin.tar.gz' do
  source 'http://www-us.apache.org/dist/maven/maven-3/3.5.3/binaries/apache-maven-3.5.3-bin.tar.gz'
	action :create
  mode '0777'
end

execute '/opt/packages/apache-maven-3.5.3-bin.tar.gz' do
    command 'tar xvzf /opt/packages/apache-maven-3.5.3-bin.tar.gz'
	cwd '/opt/packages/'
end

file '/opt/packages/apache-maven-3.5.3-bin.tar.gz' do
 action :delete
 end
 
#--------------------------------------------
#APACHE_TOMCAT

remote_file '/opt/packages/apache-tomcat-8.5.31.zip' do
  source 'http://redrockdigimark.com/apachemirror/tomcat/tomcat-8/v8.5.31/bin/apache-tomcat-8.5.31.zip'
	action :create
  mode '0777'
end

execute '/opt/packages/apache-tomcat-8.5.31.zip' do
    command 'unzip /opt/packages/apache-tomcat-8.5.31.zip'
	cwd '/opt/packages/'
end

file '/opt/packages/apache-tomcat-8.5.31.zip' do
 action :delete
end

execute 'mv /opt/packages/apache-tomcat-8.5.31 tomcat_8.5.31'do
		command 'mv /opt/packages/apache-tomcat-8.5.31 tomcat_8.5.31'
		cwd '/opt/packages'
end

 execute '/opt/packages/tomcat_8.5.31' do
		command 'chmod -R 777 /opt/packages/tomcat_8.5.31'
	cwd '/opt/packages'
end  
template '/opt/packages/tomcat_8.5.31/conf/server.xml' do
	source 'tomcat_server.xml.erb'
end
# JENKINS.war file deploy in to tomcat_webapps		
remote_file '/opt/packages/tomcat_8.5.31/webapps/jenkins.war' do
	source 'http://ftp-chi.osuosl.org/pub/jenkins/war/2.124/jenkins.war'
	action :create
#  mode '0777'
end
 execute '/opt/packages/tomcat_8.5.31/bin/shutdown.sh'
 execute '/opt/packages/tomcat_8.5.31/bin/startup.sh'
#------------------------------------------------


#NEXUS INSTALLATION
#==============================================
remote_file '/opt/packages/nexus-2.14.8-01-bundle.zip' do
  source 'https://sonatype-download.global.ssl.fastly.net/repository/repositoryManager/oss/nexus-2.14.8-01-bundle.zip'
	action :create
  mode '0777'
end

execute '/opt/packages/nexus-2.14.8-01-bundle.zip' do
		command 'unzip /opt/packages/nexus-2.14.8-01-bundle.zip'
	cwd '/opt/packages'
end

execute 'rm -rf /opt/packages/nexus-2.14.8-01-bundle.zip'

template '/opt/packages/nexus-2.14.8-01/conf/nexus.properties' do
		source 'nexus.properties.erb'
end


execute '/opt/packages/nexus-2.14.8-01/bin/nexus start' do
		command 'sh /opt/packages/nexus-2.14.8-01/bin/nexus start'
		cwd '/opt/packages'
end		

#==============================================















